package net.minecraft.advancements;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class DisplayInfo {
   private final Component title;
   private final Component description;
   private final ItemStack icon;
   @Nullable
   private final ResourceLocation background;
   private final FrameType frame;
   private final boolean showToast;
   private final boolean announceChat;
   private final boolean hidden;
   private float x;
   private float y;

   public DisplayInfo(ItemStack icon, Component title, Component description, @Nullable ResourceLocation background, FrameType frame, boolean showToast, boolean announceChat, boolean hidden) {
      this.title = title;
      this.description = description;
      this.icon = icon;
      this.background = background;
      this.frame = frame;
      this.showToast = showToast;
      this.announceChat = announceChat;
      this.hidden = hidden;
   }

   public void setLocation(float x, float y) {
      this.x = x;
      this.y = y;
   }

   public Component getTitle() {
      return this.title;
   }

   public Component getDescription() {
      return this.description;
   }

   public ItemStack getIcon() {
      return this.icon;
   }

   @Nullable
   public ResourceLocation getBackground() {
      return this.background;
   }

   public FrameType getFrame() {
      return this.frame;
   }

   public float getX() {
      return this.x;
   }

   public float getY() {
      return this.y;
   }

   public boolean shouldShowToast() {
      return this.showToast;
   }

   public boolean shouldAnnounceChat() {
      return this.announceChat;
   }

   public boolean isHidden() {
      return this.hidden;
   }

   public static DisplayInfo fromJson(JsonObject json) {
      Component component = Component.Serializer.fromJson(json.get("title"));
      Component component1 = Component.Serializer.fromJson(json.get("description"));
      if (component != null && component1 != null) {
         ItemStack itemstack = getIcon(GsonHelper.getAsJsonObject(json, "icon"));
         ResourceLocation resourcelocation = json.has("background") ? new ResourceLocation(GsonHelper.getAsString(json, "background")) : null;
         FrameType frametype = json.has("frame") ? FrameType.byName(GsonHelper.getAsString(json, "frame")) : FrameType.TASK;
         boolean flag = GsonHelper.getAsBoolean(json, "show_toast", true);
         boolean flag1 = GsonHelper.getAsBoolean(json, "announce_to_chat", true);
         boolean flag2 = GsonHelper.getAsBoolean(json, "hidden", false);
         return new DisplayInfo(itemstack, component, component1, resourcelocation, frametype, flag, flag1, flag2);
      } else {
         throw new JsonSyntaxException("Both title and description must be set");
      }
   }

   private static ItemStack getIcon(JsonObject json) {
      if (!json.has("item")) {
         throw new JsonSyntaxException("Unsupported icon type, currently only items are supported (add 'item' key)");
      } else {
         Item item = GsonHelper.getAsItem(json, "item");
         if (json.has("data")) {
            throw new JsonParseException("Disallowed data tag found");
         } else {
            ItemStack itemstack = new ItemStack(item);
            if (json.has("nbt")) {
               try {
                  CompoundTag compoundtag = TagParser.parseTag(GsonHelper.convertToString(json.get("nbt"), "nbt"));
                  itemstack.setTag(compoundtag);
               } catch (CommandSyntaxException commandsyntaxexception) {
                  throw new JsonSyntaxException("Invalid nbt tag: " + commandsyntaxexception.getMessage());
               }
            }

            return itemstack;
         }
      }
   }

   public void serializeToNetwork(FriendlyByteBuf buffer) {
      buffer.writeComponent(this.title);
      buffer.writeComponent(this.description);
      buffer.writeItem(this.icon);
      buffer.writeEnum(this.frame);
      int i = 0;
      if (this.background != null) {
         i |= 1;
      }

      if (this.showToast) {
         i |= 2;
      }

      if (this.hidden) {
         i |= 4;
      }

      buffer.writeInt(i);
      if (this.background != null) {
         buffer.writeResourceLocation(this.background);
      }

      buffer.writeFloat(this.x);
      buffer.writeFloat(this.y);
   }

   public static DisplayInfo fromNetwork(FriendlyByteBuf buffer) {
      Component component = buffer.readComponent();
      Component component1 = buffer.readComponent();
      ItemStack itemstack = buffer.readItem();
      FrameType frametype = buffer.readEnum(FrameType.class);
      int i = buffer.readInt();
      ResourceLocation resourcelocation = (i & 1) != 0 ? buffer.readResourceLocation() : null;
      boolean flag = (i & 2) != 0;
      boolean flag1 = (i & 4) != 0;
      DisplayInfo displayinfo = new DisplayInfo(itemstack, component, component1, resourcelocation, frametype, flag, false, flag1);
      displayinfo.setLocation(buffer.readFloat(), buffer.readFloat());
      return displayinfo;
   }

   public JsonElement serializeToJson() {
      JsonObject jsonobject = new JsonObject();
      jsonobject.add("icon", this.serializeIcon());
      jsonobject.add("title", Component.Serializer.toJsonTree(this.title));
      jsonobject.add("description", Component.Serializer.toJsonTree(this.description));
      jsonobject.addProperty("frame", this.frame.getName());
      jsonobject.addProperty("show_toast", this.showToast);
      jsonobject.addProperty("announce_to_chat", this.announceChat);
      jsonobject.addProperty("hidden", this.hidden);
      if (this.background != null) {
         jsonobject.addProperty("background", this.background.toString());
      }

      return jsonobject;
   }

   private JsonObject serializeIcon() {
      JsonObject jsonobject = new JsonObject();
      jsonobject.addProperty("item", BuiltInRegistries.ITEM.getKey(this.icon.getItem()).toString());
      if (this.icon.hasTag()) {
         jsonobject.addProperty("nbt", this.icon.getTag().toString());
      }

      return jsonobject;
   }
}
