package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class BeeNestDestroyedTrigger extends SimpleCriterionTrigger<BeeNestDestroyedTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("bee_nest_destroyed");

   public ResourceLocation getId() {
      return ID;
   }

   public BeeNestDestroyedTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      Block block = deserializeBlock(json);
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.fromJson(json.get("num_bees_inside"));
      return new BeeNestDestroyedTrigger.TriggerInstance(predicate, block, itempredicate, minmaxbounds$ints);
   }

   @Nullable
   private static Block deserializeBlock(JsonObject json) {
      if (json.has("block")) {
         ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.getAsString(json, "block"));
         return BuiltInRegistries.BLOCK.getOptional(resourcelocation).orElseThrow(() -> {
            return new JsonSyntaxException("Unknown block type '" + resourcelocation + "'");
         });
      } else {
         return null;
      }
   }

   public void trigger(ServerPlayer player, BlockState state, ItemStack stack, int numBees) {
      this.trigger(player, (p_146660_) -> {
         return p_146660_.matches(state, stack, numBees);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      @Nullable
      private final Block block;
      private final ItemPredicate item;
      private final MinMaxBounds.Ints numBees;

      public TriggerInstance(ContextAwarePredicate player, @Nullable Block block, ItemPredicate item, MinMaxBounds.Ints numBees) {
         super(BeeNestDestroyedTrigger.ID, player);
         this.block = block;
         this.item = item;
         this.numBees = numBees;
      }

      public static BeeNestDestroyedTrigger.TriggerInstance destroyedBeeNest(Block block, ItemPredicate.Builder itemPredicateBuilder, MinMaxBounds.Ints beesContained) {
         return new BeeNestDestroyedTrigger.TriggerInstance(ContextAwarePredicate.ANY, block, itemPredicateBuilder.build(), beesContained);
      }

      public boolean matches(BlockState state, ItemStack stack, int numBees) {
         if (this.block != null && !state.is(this.block)) {
            return false;
         } else {
            return !this.item.matches(stack) ? false : this.numBees.matches(numBees);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         if (this.block != null) {
            jsonobject.addProperty("block", BuiltInRegistries.BLOCK.getKey(this.block).toString());
         }

         jsonobject.add("item", this.item.serializeToJson());
         jsonobject.add("num_bees_inside", this.numBees.serializeToJson());
         return jsonobject;
      }
   }
}
