package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;

public class LootTableTrigger extends SimpleCriterionTrigger<LootTableTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("player_generates_container_loot");

   public ResourceLocation getId() {
      return ID;
   }

   protected LootTableTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.getAsString(json, "loot_table"));
      return new LootTableTrigger.TriggerInstance(predicate, resourcelocation);
   }

   public void trigger(ServerPlayer player, ResourceLocation lootTable) {
      this.trigger(player, (p_54606_) -> {
         return p_54606_.matches(lootTable);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ResourceLocation lootTable;

      public TriggerInstance(ContextAwarePredicate player, ResourceLocation lootTable) {
         super(LootTableTrigger.ID, player);
         this.lootTable = lootTable;
      }

      public static LootTableTrigger.TriggerInstance lootTableUsed(ResourceLocation lootTable) {
         return new LootTableTrigger.TriggerInstance(ContextAwarePredicate.ANY, lootTable);
      }

      public boolean matches(ResourceLocation lootTable) {
         return this.lootTable.equals(lootTable);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.addProperty("loot_table", this.lootTable.toString());
         return jsonobject;
      }
   }
}
