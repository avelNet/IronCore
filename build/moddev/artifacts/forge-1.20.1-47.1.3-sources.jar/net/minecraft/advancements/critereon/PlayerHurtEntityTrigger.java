package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;

public class PlayerHurtEntityTrigger extends SimpleCriterionTrigger<PlayerHurtEntityTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("player_hurt_entity");

   public ResourceLocation getId() {
      return ID;
   }

   public PlayerHurtEntityTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      DamagePredicate damagepredicate = DamagePredicate.fromJson(json.get("damage"));
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "entity", deserializationContext);
      return new PlayerHurtEntityTrigger.TriggerInstance(predicate, damagepredicate, contextawarepredicate);
   }

   public void trigger(ServerPlayer player, Entity entity, DamageSource source, float amountDealt, float amountTaken, boolean blocked) {
      LootContext lootcontext = EntityPredicate.createContext(player, entity);
      this.trigger(player, (p_60126_) -> {
         return p_60126_.matches(player, lootcontext, source, amountDealt, amountTaken, blocked);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final DamagePredicate damage;
      private final ContextAwarePredicate entity;

      public TriggerInstance(ContextAwarePredicate player, DamagePredicate damage, ContextAwarePredicate entity) {
         super(PlayerHurtEntityTrigger.ID, player);
         this.damage = damage;
         this.entity = entity;
      }

      public static PlayerHurtEntityTrigger.TriggerInstance playerHurtEntity() {
         return new PlayerHurtEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, DamagePredicate.ANY, ContextAwarePredicate.ANY);
      }

      public static PlayerHurtEntityTrigger.TriggerInstance playerHurtEntity(DamagePredicate damage) {
         return new PlayerHurtEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, damage, ContextAwarePredicate.ANY);
      }

      public static PlayerHurtEntityTrigger.TriggerInstance playerHurtEntity(DamagePredicate.Builder damageBuilder) {
         return new PlayerHurtEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, damageBuilder.build(), ContextAwarePredicate.ANY);
      }

      public static PlayerHurtEntityTrigger.TriggerInstance playerHurtEntity(EntityPredicate entity) {
         return new PlayerHurtEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, DamagePredicate.ANY, EntityPredicate.wrap(entity));
      }

      public static PlayerHurtEntityTrigger.TriggerInstance playerHurtEntity(DamagePredicate damage, EntityPredicate entity) {
         return new PlayerHurtEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, damage, EntityPredicate.wrap(entity));
      }

      public static PlayerHurtEntityTrigger.TriggerInstance playerHurtEntity(DamagePredicate.Builder damageBuilder, EntityPredicate entity) {
         return new PlayerHurtEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, damageBuilder.build(), EntityPredicate.wrap(entity));
      }

      public boolean matches(ServerPlayer player, LootContext context, DamageSource damage, float dealt, float taken, boolean blocked) {
         if (!this.damage.matches(player, damage, dealt, taken, blocked)) {
            return false;
         } else {
            return this.entity.matches(context);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("damage", this.damage.serializeToJson());
         jsonobject.add("entity", this.entity.toJson(conditions));
         return jsonobject;
      }
   }
}
