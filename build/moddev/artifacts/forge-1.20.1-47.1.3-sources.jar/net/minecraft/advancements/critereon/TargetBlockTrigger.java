package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.phys.Vec3;

public class TargetBlockTrigger extends SimpleCriterionTrigger<TargetBlockTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("target_hit");

   public ResourceLocation getId() {
      return ID;
   }

   public TargetBlockTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.fromJson(json.get("signal_strength"));
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "projectile", deserializationContext);
      return new TargetBlockTrigger.TriggerInstance(predicate, minmaxbounds$ints, contextawarepredicate);
   }

   public void trigger(ServerPlayer player, Entity projectile, Vec3 vector, int signalStrength) {
      LootContext lootcontext = EntityPredicate.createContext(player, projectile);
      this.trigger(player, (p_70224_) -> {
         return p_70224_.matches(lootcontext, vector, signalStrength);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final MinMaxBounds.Ints signalStrength;
      private final ContextAwarePredicate projectile;

      public TriggerInstance(ContextAwarePredicate player, MinMaxBounds.Ints signalStrength, ContextAwarePredicate projectile) {
         super(TargetBlockTrigger.ID, player);
         this.signalStrength = signalStrength;
         this.projectile = projectile;
      }

      public static TargetBlockTrigger.TriggerInstance targetHit(MinMaxBounds.Ints signalStrength, ContextAwarePredicate projectile) {
         return new TargetBlockTrigger.TriggerInstance(ContextAwarePredicate.ANY, signalStrength, projectile);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("signal_strength", this.signalStrength.serializeToJson());
         jsonobject.add("projectile", this.projectile.toJson(conditions));
         return jsonobject;
      }

      public boolean matches(LootContext context, Vec3 vector, int signalStrength) {
         if (!this.signalStrength.matches(signalStrength)) {
            return false;
         } else {
            return this.projectile.matches(context);
         }
      }
   }
}
