package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

public class UsedEnderEyeTrigger extends SimpleCriterionTrigger<UsedEnderEyeTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("used_ender_eye");

   public ResourceLocation getId() {
      return ID;
   }

   public UsedEnderEyeTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      MinMaxBounds.Doubles minmaxbounds$doubles = MinMaxBounds.Doubles.fromJson(json.get("distance"));
      return new UsedEnderEyeTrigger.TriggerInstance(predicate, minmaxbounds$doubles);
   }

   public void trigger(ServerPlayer player, BlockPos pos) {
      double d0 = player.getX() - (double)pos.getX();
      double d1 = player.getZ() - (double)pos.getZ();
      double d2 = d0 * d0 + d1 * d1;
      this.trigger(player, (p_73934_) -> {
         return p_73934_.matches(d2);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final MinMaxBounds.Doubles level;

      public TriggerInstance(ContextAwarePredicate player, MinMaxBounds.Doubles level) {
         super(UsedEnderEyeTrigger.ID, player);
         this.level = level;
      }

      public boolean matches(double distanceSq) {
         return this.level.matchesSqr(distanceSq);
      }
   }
}
