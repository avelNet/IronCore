package net.minecraft.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class Timer {
   public float partialTick;
   public float tickDelta;
   private long lastMs;
   private final float msPerTick;

   public Timer(float ticksPerSecond, long lastMs) {
      this.msPerTick = 1000.0F / ticksPerSecond;
      this.lastMs = lastMs;
   }

   public int advanceTime(long gameTime) {
      this.tickDelta = (float)(gameTime - this.lastMs) / this.msPerTick;
      this.lastMs = gameTime;
      this.partialTick += this.tickDelta;
      int i = (int)this.partialTick;
      this.partialTick -= (float)i;
      return i;
   }
}
