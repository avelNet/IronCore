package net.minecraft.client.gui.components;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TextAndImageButton extends Button {
   protected final ResourceLocation resourceLocation;
   protected final int xTexStart;
   protected final int yTexStart;
   protected final int yDiffTex;
   protected final int textureWidth;
   protected final int textureHeight;
   private final int xOffset;
   private final int yOffset;
   private final int usedTextureWidth;
   private final int usedTextureHeight;

   TextAndImageButton(Component message, int xTexStart, int yTexStart, int xOffset, int yOffset, int yDiffTex, int usedTextureWidth, int usedTextureHeight, int textureWidth, int textureHeight, ResourceLocation resourceLocation, Button.OnPress onPress) {
      super(0, 0, 150, 20, message, onPress, DEFAULT_NARRATION);
      this.textureWidth = textureWidth;
      this.textureHeight = textureHeight;
      this.xTexStart = xTexStart;
      this.yTexStart = yTexStart;
      this.yDiffTex = yDiffTex;
      this.resourceLocation = resourceLocation;
      this.xOffset = xOffset;
      this.yOffset = yOffset;
      this.usedTextureWidth = usedTextureWidth;
      this.usedTextureHeight = usedTextureHeight;
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      super.renderWidget(guiGraphics, mouseX, mouseY, partialTick);
      this.renderTexture(guiGraphics, this.resourceLocation, this.getXOffset(), this.getYOffset(), this.xTexStart, this.yTexStart, this.yDiffTex, this.usedTextureWidth, this.usedTextureHeight, this.textureWidth, this.textureHeight);
   }

   public void renderString(GuiGraphics guiGraphics, Font font, int color) {
      int i = this.getX() + 2;
      int j = this.getX() + this.getWidth() - this.usedTextureWidth - 6;
      renderScrollingString(guiGraphics, font, this.getMessage(), i, this.getY(), j, this.getY() + this.getHeight(), color);
   }

   private int getXOffset() {
      return this.getX() + (this.width / 2 - this.usedTextureWidth / 2) + this.xOffset;
   }

   private int getYOffset() {
      return this.getY() + this.yOffset;
   }

   public static TextAndImageButton.Builder builder(Component message, ResourceLocation resourceLocation, Button.OnPress onPress) {
      return new TextAndImageButton.Builder(message, resourceLocation, onPress);
   }

   @OnlyIn(Dist.CLIENT)
   public static class Builder {
      private final Component message;
      private final ResourceLocation resourceLocation;
      private final Button.OnPress onPress;
      private int xTexStart;
      private int yTexStart;
      private int yDiffTex;
      private int usedTextureWidth;
      private int usedTextureHeight;
      private int textureWidth;
      private int textureHeight;
      private int xOffset;
      private int yOffset;

      public Builder(Component message, ResourceLocation resourceLocation, Button.OnPress onPress) {
         this.message = message;
         this.resourceLocation = resourceLocation;
         this.onPress = onPress;
      }

      public TextAndImageButton.Builder texStart(int x, int y) {
         this.xTexStart = x;
         this.yTexStart = y;
         return this;
      }

      public TextAndImageButton.Builder offset(int x, int y) {
         this.xOffset = x;
         this.yOffset = y;
         return this;
      }

      public TextAndImageButton.Builder yDiffTex(int yDiffTex) {
         this.yDiffTex = yDiffTex;
         return this;
      }

      public TextAndImageButton.Builder usedTextureSize(int width, int height) {
         this.usedTextureWidth = width;
         this.usedTextureHeight = height;
         return this;
      }

      public TextAndImageButton.Builder textureSize(int width, int height) {
         this.textureWidth = width;
         this.textureHeight = height;
         return this;
      }

      public TextAndImageButton build() {
         return new TextAndImageButton(this.message, this.xTexStart, this.yTexStart, this.xOffset, this.yOffset, this.yDiffTex, this.usedTextureWidth, this.usedTextureHeight, this.textureWidth, this.textureHeight, this.resourceLocation, this.onPress);
      }
   }
}
