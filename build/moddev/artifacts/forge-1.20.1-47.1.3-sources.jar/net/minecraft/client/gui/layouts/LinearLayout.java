package net.minecraft.client.gui.layouts;

import com.mojang.math.Divisor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class LinearLayout extends AbstractLayout {
   private final LinearLayout.Orientation orientation;
   private final List<LinearLayout.ChildContainer> children = new ArrayList<>();
   private final LayoutSettings defaultChildLayoutSettings = LayoutSettings.defaults();

   public LinearLayout(int width, int height, LinearLayout.Orientation orientation) {
      this(0, 0, width, height, orientation);
   }

   public LinearLayout(int x, int y, int width, int height, LinearLayout.Orientation orientation) {
      super(x, y, width, height);
      this.orientation = orientation;
   }

   public void arrangeElements() {
      super.arrangeElements();
      if (!this.children.isEmpty()) {
         int i = 0;
         int j = this.orientation.getSecondaryLength(this);

         for(LinearLayout.ChildContainer linearlayout$childcontainer : this.children) {
            i += this.orientation.getPrimaryLength(linearlayout$childcontainer);
            j = Math.max(j, this.orientation.getSecondaryLength(linearlayout$childcontainer));
         }

         int k = this.orientation.getPrimaryLength(this) - i;
         int l = this.orientation.getPrimaryPosition(this);
         Iterator<LinearLayout.ChildContainer> iterator = this.children.iterator();
         LinearLayout.ChildContainer linearlayout$childcontainer1 = iterator.next();
         this.orientation.setPrimaryPosition(linearlayout$childcontainer1, l);
         l += this.orientation.getPrimaryLength(linearlayout$childcontainer1);
         LinearLayout.ChildContainer linearlayout$childcontainer2;
         if (this.children.size() >= 2) {
            for(Divisor divisor = new Divisor(k, this.children.size() - 1); divisor.hasNext(); l += this.orientation.getPrimaryLength(linearlayout$childcontainer2)) {
               l += divisor.nextInt();
               linearlayout$childcontainer2 = iterator.next();
               this.orientation.setPrimaryPosition(linearlayout$childcontainer2, l);
            }
         }

         int i1 = this.orientation.getSecondaryPosition(this);

         for(LinearLayout.ChildContainer linearlayout$childcontainer3 : this.children) {
            this.orientation.setSecondaryPosition(linearlayout$childcontainer3, i1, j);
         }

         switch (this.orientation) {
            case HORIZONTAL:
               this.height = j;
               break;
            case VERTICAL:
               this.width = j;
         }

      }
   }

   public void visitChildren(Consumer<LayoutElement> consumer) {
      this.children.forEach((p_265178_) -> {
         consumer.accept(p_265178_.child);
      });
   }

   public LayoutSettings newChildLayoutSettings() {
      return this.defaultChildLayoutSettings.copy();
   }

   public LayoutSettings defaultChildLayoutSetting() {
      return this.defaultChildLayoutSettings;
   }

   public <T extends LayoutElement> T addChild(T child) {
      return this.addChild(child, this.newChildLayoutSettings());
   }

   public <T extends LayoutElement> T addChild(T child, LayoutSettings layoutSettings) {
      this.children.add(new LinearLayout.ChildContainer(child, layoutSettings));
      return child;
   }

   @OnlyIn(Dist.CLIENT)
   static class ChildContainer extends AbstractLayout.AbstractChildWrapper {
      protected ChildContainer(LayoutElement p_265706_, LayoutSettings p_265131_) {
         super(p_265706_, p_265131_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static enum Orientation {
      HORIZONTAL,
      VERTICAL;

      int getPrimaryLength(LayoutElement element) {
         int i;
         switch (this) {
            case HORIZONTAL:
               i = element.getWidth();
               break;
            case VERTICAL:
               i = element.getHeight();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return i;
      }

      int getPrimaryLength(LinearLayout.ChildContainer cotainer) {
         int i;
         switch (this) {
            case HORIZONTAL:
               i = cotainer.getWidth();
               break;
            case VERTICAL:
               i = cotainer.getHeight();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return i;
      }

      int getSecondaryLength(LayoutElement element) {
         int i;
         switch (this) {
            case HORIZONTAL:
               i = element.getHeight();
               break;
            case VERTICAL:
               i = element.getWidth();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return i;
      }

      int getSecondaryLength(LinearLayout.ChildContainer container) {
         int i;
         switch (this) {
            case HORIZONTAL:
               i = container.getHeight();
               break;
            case VERTICAL:
               i = container.getWidth();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return i;
      }

      void setPrimaryPosition(LinearLayout.ChildContainer container, int primaryPosition) {
         switch (this) {
            case HORIZONTAL:
               container.setX(primaryPosition, container.getWidth());
               break;
            case VERTICAL:
               container.setY(primaryPosition, container.getHeight());
         }

      }

      void setSecondaryPosition(LinearLayout.ChildContainer container, int secondaryPosition, int secondaryLength) {
         switch (this) {
            case HORIZONTAL:
               container.setY(secondaryPosition, secondaryLength);
               break;
            case VERTICAL:
               container.setX(secondaryPosition, secondaryLength);
         }

      }

      int getPrimaryPosition(LayoutElement element) {
         int i;
         switch (this) {
            case HORIZONTAL:
               i = element.getX();
               break;
            case VERTICAL:
               i = element.getY();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return i;
      }

      int getSecondaryPosition(LayoutElement element) {
         int i;
         switch (this) {
            case HORIZONTAL:
               i = element.getY();
               break;
            case VERTICAL:
               i = element.getX();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return i;
      }
   }
}
