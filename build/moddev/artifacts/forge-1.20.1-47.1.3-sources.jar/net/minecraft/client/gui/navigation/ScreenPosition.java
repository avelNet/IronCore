package net.minecraft.client.gui.navigation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public record ScreenPosition(int x, int y) {
   public static ScreenPosition of(ScreenAxis axis, int primaryPosition, int secondaryPosition) {
      ScreenPosition screenposition;
      switch (axis) {
         case HORIZONTAL:
            screenposition = new ScreenPosition(primaryPosition, secondaryPosition);
            break;
         case VERTICAL:
            screenposition = new ScreenPosition(secondaryPosition, primaryPosition);
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return screenposition;
   }

   public ScreenPosition step(ScreenDirection direction) {
      ScreenPosition screenposition;
      switch (direction) {
         case DOWN:
            screenposition = new ScreenPosition(this.x, this.y + 1);
            break;
         case UP:
            screenposition = new ScreenPosition(this.x, this.y - 1);
            break;
         case LEFT:
            screenposition = new ScreenPosition(this.x - 1, this.y);
            break;
         case RIGHT:
            screenposition = new ScreenPosition(this.x + 1, this.y);
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return screenposition;
   }

   public int getCoordinate(ScreenAxis axis) {
      int i;
      switch (axis) {
         case HORIZONTAL:
            i = this.x;
            break;
         case VERTICAL:
            i = this.y;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return i;
   }
}
