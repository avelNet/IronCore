package net.minecraft.client.gui.screens.inventory;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundRenameItemPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class AnvilScreen extends ItemCombinerScreen<AnvilMenu> {
   private static final ResourceLocation ANVIL_LOCATION = new ResourceLocation("textures/gui/container/anvil.png");
   private static final Component TOO_EXPENSIVE_TEXT = Component.translatable("container.repair.expensive");
   private EditBox name;
   private final Player player;

   public AnvilScreen(AnvilMenu menu, Inventory playerInventory, Component title) {
      super(menu, playerInventory, title, ANVIL_LOCATION);
      this.player = playerInventory.player;
      this.titleLabelX = 60;
   }

   public void containerTick() {
      super.containerTick();
      this.name.tick();
   }

   protected void subInit() {
      int i = (this.width - this.imageWidth) / 2;
      int j = (this.height - this.imageHeight) / 2;
      this.name = new EditBox(this.font, i + 62, j + 24, 103, 12, Component.translatable("container.repair"));
      this.name.setCanLoseFocus(false);
      this.name.setTextColor(-1);
      this.name.setTextColorUneditable(-1);
      this.name.setBordered(false);
      this.name.setMaxLength(50);
      this.name.setResponder(this::onNameChanged);
      this.name.setValue("");
      this.addWidget(this.name);
      this.setInitialFocus(this.name);
      this.name.setEditable(false);
   }

   public void resize(Minecraft minecraft, int width, int height) {
      String s = this.name.getValue();
      this.init(minecraft, width, height);
      this.name.setValue(s);
   }

   /**
    * Called when a keyboard key is pressed within the GUI element.
    * <p>
    * @return {@code true} if the event is consumed, {@code false} otherwise.
    *
    * @param keyCode   the key code of the pressed key.
    * @param scanCode  the scan code of the pressed key.
    * @param modifiers the keyboard modifiers.
    */
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256) {
         this.minecraft.player.closeContainer();
      }

      return !this.name.keyPressed(keyCode, scanCode, modifiers) && !this.name.canConsumeInput() ? super.keyPressed(keyCode, scanCode, modifiers) : true;
   }

   private void onNameChanged(String name) {
      Slot slot = this.menu.getSlot(0);
      if (slot.hasItem()) {
         String s = name;
         if (!slot.getItem().hasCustomHoverName() && name.equals(slot.getItem().getHoverName().getString())) {
            s = "";
         }

         if (this.menu.setItemName(s)) {
            this.minecraft.player.connection.send(new ServerboundRenameItemPacket(s));
         }

      }
   }

   protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      super.renderLabels(guiGraphics, mouseX, mouseY);
      int i = this.menu.getCost();
      if (i > 0) {
         int j = 8453920;
         Component component;
         if (i >= 40 && !this.minecraft.player.getAbilities().instabuild) {
            component = TOO_EXPENSIVE_TEXT;
            j = 16736352;
         } else if (!this.menu.getSlot(2).hasItem()) {
            component = null;
         } else {
            component = Component.translatable("container.repair.cost", i);
            if (!this.menu.getSlot(2).mayPickup(this.player)) {
               j = 16736352;
            }
         }

         if (component != null) {
            int k = this.imageWidth - 8 - this.font.width(component) - 2;
            int l = 69;
            guiGraphics.fill(k - 2, 67, this.imageWidth - 8, 79, 1325400064);
            guiGraphics.drawString(this.font, component, k, 69, j);
         }
      }

   }

   protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
      super.renderBg(guiGraphics, partialTick, mouseX, mouseY);
      guiGraphics.blit(ANVIL_LOCATION, this.leftPos + 59, this.topPos + 20, 0, this.imageHeight + (this.menu.getSlot(0).hasItem() ? 0 : 16), 110, 16);
   }

   public void renderFg(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      this.name.render(guiGraphics, mouseX, mouseY, partialTick);
   }

   protected void renderErrorIcon(GuiGraphics guiGraphics, int x, int y) {
      if ((this.menu.getSlot(0).hasItem() || this.menu.getSlot(1).hasItem()) && !this.menu.getSlot(this.menu.getResultSlot()).hasItem()) {
         guiGraphics.blit(ANVIL_LOCATION, x + 99, y + 45, this.imageWidth, 0, 28, 21);
      }

   }

   /**
    * Sends the contents of an inventory slot to the client-side Container. This doesn't have to match the actual contents of that slot.
    */
   public void slotChanged(AbstractContainerMenu containerToSend, int slotInd, ItemStack stack) {
      if (slotInd == 0) {
         this.name.setValue(stack.isEmpty() ? "" : stack.getHoverName().getString());
         this.name.setEditable(!stack.isEmpty());
         this.setFocused(this.name);
      }

   }
}
